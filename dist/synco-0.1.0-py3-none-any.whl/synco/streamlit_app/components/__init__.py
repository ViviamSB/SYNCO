"""Streamlit app components."""
